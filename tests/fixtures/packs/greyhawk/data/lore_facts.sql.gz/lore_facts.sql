CREATE TABLE lore_facts (id INTEGER PRIMARY KEY, text TEXT NOT NULL, category TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '');
INSERT INTO lore_facts (id, text, category, source) VALUES (1, 'The Circle of Eight keeps any one power from ruling the Flanaess.', 'greyhawk', 'seed');
INSERT INTO lore_facts (id, text, category, source) VALUES (2, 'A lich''s life is bound to its phylactery.', 'monster', 'seed');
INSERT INTO lore_facts (id, text, category, source) VALUES (3, 'THAC0 means To Hit Armor Class 0.', 'rules', 'seed');
INSERT INTO lore_facts (id, text, category, source) VALUES (4, 'Iuz is the son of Iggwilv.', 'greyhawk', 'seed');
INSERT INTO lore_facts (id, text, category, source) VALUES (5, 'The Twin Cataclysms ended the Suel Imperium.', 'history', 'seed');
