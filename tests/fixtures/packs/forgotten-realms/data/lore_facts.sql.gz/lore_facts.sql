CREATE TABLE lore_facts (id INTEGER PRIMARY KEY, text TEXT NOT NULL, category TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '');
INSERT INTO "lore_facts" VALUES(2,'A lich''s life is bound to its phylactery.','monster','seed');
INSERT INTO "lore_facts" VALUES(3,'THAC0 means To Hit Armor Class 0.','rules','seed');
